import { request } from 'node:http';

/** HTTP framing over a local Unix socket; no network listener is involved. */
export function controlRequest(
  socketPath: string,
  path: string,
  input?: unknown,
): Promise<{ status: number; value: unknown }> {
  return new Promise((resolve, reject) => {
    const body = input === undefined ? undefined : JSON.stringify(input);
    const req = request(
      {
        socketPath,
        path,
        method: body === undefined ? 'GET' : 'POST',
        headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(15000),
      },
      async (response) => {
        try {
          const chunks: Buffer[] = [];
          for await (const chunk of response) {
            if (!Buffer.isBuffer(chunk)) throw new Error('Expected bytes from the control socket.');
            chunks.push(chunk);
          }
          resolve({
            status: response.statusCode!,
            value: JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown,
          });
        } catch (error) {
          reject(error);
        }
      },
    );
    req.once('error', reject);
    req.end(body);
  });
}
