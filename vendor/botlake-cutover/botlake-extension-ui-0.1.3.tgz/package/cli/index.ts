import { readFileSync } from 'node:fs';
import { parseArgs } from 'node:util';
import { isAbsolute } from 'node:path';
import { defaultControlSocket } from '../contracts/control-socket.ts';
import { controlRequest } from './transport.ts';
import { z } from 'zod';
import { settingsChangeSchema, settingsSchema, sourceViews } from '../contracts/settings.ts';
import {
  clientInfoSchema,
  showRequestSchema,
  clientAckSchema,
  openRequestSchema,
  openResultSchema,
} from '../contracts/client-control.ts';
import { deviceInfoSchema, nameDeviceSchema } from '../contracts/notifications.ts';

const help = `Botlake UI — shared views and live client control

Usage: botlake bin run ui COMMAND [--input JSON|@FILE|-]

  clients list               All connected clients and their last reported state
  clients inspect --client ID
  devices list               Enrolled push devices, excluding credentials
  devices name --input …     Rename: {"id":"…","name":"Adam’s iPhone","expectedRevision":1}
  open ID               Open a task, group or agent on --device phone; push when closed
  settings get               Shared view definitions and current revision
  settings change --input …  Revision-checked change; see schema or OpenAPI
  views list --source ID     Saved tabs for a lake or combined selection
  lakes list                 Discover source IDs
  show --input …             Display work on one foreground client, awaiting acknowledgement
  schema                     OpenAPI 3.1 document for the control API
  skills list                Discover bundled agent instructions
  skills get botlake-ui      Read the short phone/client workflow

JSON output: {ok:true,data:…} or {ok:false,error:{code,message}}.
Exit 0 confirms success; exit 1 reports rejection or failure. No mutation retries.
Socket: --socket, then BOTLAKE_UI_SOCKET, then ~/.local/state/botlake-ui/control.sock.
Client IDs identify open pages; refresh creates a new ID. Omit client only when
exactly one client is visible. Finish drafts before remote navigation.
Use settings get's revision as expectedRevision in settings change.
open uses --workspace or BOTLAKE_UI_WORKSPACE; --source selects a lake ID instead.
The registered binary supplies the local socket and workspace automatically:
  botlake bin run ui open ID
ID is a Work item ID, agent identity node ID or unique agent name.
opened means the client acknowledged the requested view. notification_sent means
the push service accepted a tap-to-open notification, not that the person saw it.
`;

class CliError extends Error {
  constructor(
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}
const jsonInput = (value: string | undefined): unknown => {
  if (value === undefined)
    throw new CliError('input_required', 'Supply --input JSON, @FILE or - for stdin.');
  return JSON.parse(
    value === '-'
      ? readFileSync(0, 'utf8')
      : value.startsWith('@')
        ? readFileSync(value.slice(1), 'utf8')
        : value,
  ) as unknown;
};

export async function run(args: string[]): Promise<unknown> {
  const { values, positionals } = parseArgs({
    args,
    allowPositionals: true,
    options: {
      socket: { type: 'string' },
      input: { type: 'string' },
      client: { type: 'string' },
      source: { type: 'string' },
      workspace: { type: 'string' },
      device: { type: 'string' },
      help: { type: 'boolean', short: 'h' },
    },
  });
  if (values.help || positionals.length === 0) return { help };
  if (positionals.join(' ') === 'skills list')
    return {
      items: [
        {
          name: 'botlake-ui',
          description:
            'Open Botlake tasks, groups and agents on a phone and control connected views.',
        },
      ],
      complete: true,
    };
  if (positionals.join(' ') === 'skills get botlake-ui')
    return {
      name: 'botlake-ui',
      body: readFileSync(new URL('../skills/botlake-ui/SKILL.md', import.meta.url), 'utf8'),
    };
  const socket = values.socket ?? process.env['BOTLAKE_UI_SOCKET'] ?? defaultControlSocket;
  if (!isAbsolute(socket)) throw new CliError('invalid_socket', 'Use an absolute socket path.');
  const call = async (path: string, input?: unknown): Promise<unknown> => {
    const response = await controlRequest(socket, path, input).catch((error: unknown) => {
      const message = error instanceof Error ? error.message : 'Control connection failed.';
      throw new CliError(
        input === undefined ? 'request_failed' : 'outcome_unknown',
        input === undefined
          ? message
          : `${message} The command may have applied. Inspect settings or client/device state before trying again.`,
      );
    });
    const result = response.value;
    if (response.status >= 400) {
      const error = z.object({ error: z.string(), code: z.string().optional() }).parse(result);
      throw new CliError(error.code ?? `http_${response.status}`, error.error);
    }
    return result;
  };
  const command = positionals.join(' ');
  if (positionals[0] === 'open' && positionals.length === 2) {
    const workspace = values.workspace ?? process.env['BOTLAKE_UI_WORKSPACE'];
    const input = openRequestSchema.parse({
      id: positionals[1],
      device: values.device,
      ...(values.source ? { source: values.source } : { workspace }),
    });
    return openResultSchema.parse(await call('/api/open', input));
  }
  switch (command) {
    case 'devices list':
      return z
        .object({ items: deviceInfoSchema.array(), complete: z.literal(true) })
        .parse(await call('/api/devices'));
    case 'devices name':
      return deviceInfoSchema.parse(
        await call('/api/devices/name', nameDeviceSchema.parse(jsonInput(values.input))),
      );
    case 'clients list':
    case 'clients inspect': {
      const result = z
        .object({ items: clientInfoSchema.array(), complete: z.literal(true) })
        .parse(await call('/api/clients'));
      if (command === 'clients list') return result;
      if (!values.client)
        throw new CliError('client_required', 'Supply --client ID from clients list.');
      const client = result.items.find((item) => item.id === values.client);
      if (!client)
        throw new CliError('client_unavailable', 'Client is not connected. Run clients list.');
      return client;
    }
    case 'settings get':
      return settingsSchema.parse(await call('/api/settings'));
    case 'settings change': {
      const input = settingsChangeSchema.parse(jsonInput(values.input));
      const result = settingsSchema.parse(await call('/api/settings', input));
      return { revision: result.revision, action: input.change.action };
    }
    case 'views list': {
      if (!values.source)
        throw new CliError(
          'source_required',
          'Supply --source ID from lakes list or settings get.',
        );
      const settings = settingsSchema.parse(await call('/api/settings'));
      return {
        revision: settings.revision,
        source: values.source,
        items: sourceViews(settings, values.source),
        complete: true,
      };
    }
    case 'lakes list':
      return { items: await call('/api/workspaces?refresh'), complete: true };
    case 'show': {
      const input = showRequestSchema.parse(jsonInput(values.input));
      const result = clientAckSchema
        .extend({ client: z.uuid() })
        .parse(await call('/api/show', input));
      if (result.status === 'rejected')
        throw new CliError(
          'client_rejected',
          result.message ?? 'The client declined this request.',
        );
      return result;
    }
    case 'schema':
      return call('/api/openapi.json');
    default:
      throw new CliError('unknown_command', 'Unknown command. Run botlake-ui --help.');
  }
}

export async function main(args: string[]): Promise<void> {
  try {
    console.log(JSON.stringify({ ok: true, data: await run(args) }));
  } catch (error) {
    console.log(
      JSON.stringify({
        ok: false,
        error: {
          code:
            error instanceof CliError
              ? error.code
              : error instanceof z.ZodError
                ? 'invalid_input'
                : 'request_failed',
          message: error instanceof Error ? error.message : 'Command failed.',
        },
      }),
    );
    process.exitCode = 1;
  }
}
