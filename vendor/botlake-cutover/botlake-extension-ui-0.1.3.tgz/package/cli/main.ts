#!/usr/bin/env bun
import { main } from './index.ts';

await main(process.argv.slice(2));
