# Botlake UI extension

Registers UI controls in a Botlake lake. Requires Bun, Botlake and a separately running Botlake UI server on the same machine; installing this package does not start the dashboard.

From the lake's `.botlake` directory:

```sh
bun add @botlake/extension-ui
```

Add `"@botlake/extension-ui"` to the manifest's `botlake.extensions` array, keeping any existing selections. Start or restart the lake, then run:

```sh
botlake bin run ui --help
botlake bin run ui clients list
botlake bin run ui open ID
```

Published packages contain TypeScript source. Botlake's Bun supervisor imports the extension, and the registered executable runs the packaged Bun TypeScript CLI directly; no build step is needed. `open` accepts a task, group or agent identity ID and targets the enrolled device `phone` by default.

The default UI control socket is `~/.local/state/botlake-ui/control.sock`. To select another socket, configure a local module instead of selecting the package directly:

```ts
import { ui } from '@botlake/extension-ui';

export default ui({ socket: '/absolute/path/to/control.sock' });
```

Select that module in `botlake.extensions`. The registration supplies the lake workspace to each CLI invocation.
