import { fileURLToPath } from 'node:url';
import { isAbsolute } from 'node:path';
import { defaultControlSocket } from './contracts/control-socket.ts';

/** Optional lake registration. The CLI executes in the caller, not in the lake. */
export function ui({ socket = defaultControlSocket }: { socket?: string } = {}) {
  if (!isAbsolute(socket)) throw new Error('UI control socket must be an absolute path.');
  return {
    name: 'ui',
    source: import.meta.url,
    activate(ctx: {
      workspace: string;
      bin(
        name: string,
        definition: {
          description: string;
          exec:
            | { path: string; env?: Record<string, string> }
            | { command: string; env?: Record<string, string> };
          build?: { argv: string[]; cwd: string };
        },
      ): void;
    }) {
      ctx.bin('ui', {
        description:
          'Open a task on your phone, manage shared views and control connected clients. Run ui --help.',
        exec: {
          path: fileURLToPath(new URL('./cli/main.ts', import.meta.url)),
          env: { BOTLAKE_UI_SOCKET: socket, BOTLAKE_UI_WORKSPACE: ctx.workspace },
        },
      });
    },
  };
}

export default ui();
