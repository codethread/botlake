---
name: botlake-ui
description: Open a Botlake task, group or agent on the user's phone or control a connected work view when asked to “bring that up on my phone” or “show me” matching work.
---

Discover the selected lake's utilities with `botlake bin list`. When `ui` is registered, run `botlake bin run ui open ID` for a known task, group or agent in that lake. Use the Work item ID or agent identity node ID; a unique agent name is also accepted. The registration supplies the lake and local control socket; the default device is `phone`. Use `botlake bin run --workspace LAKE ui open ID` to select another lake.

Report the returned outcome: `opened` confirms navigation on a foreground client; `notification_sent` means a tap-to-open push was accepted. The latter needs the user to tap it. A busy client retains its editor; ask the user to finish it. After an acknowledgement timeout, inspect client state before another command: the first may already have applied.

The phone must enable notifications first; enrollment assigns a stable alias such as `phone`. Discover IDs, aliases, display names and revisions with `devices list`. Rename using `devices name` with `id`, `name` and `expectedRevision`; names may contain spaces and apostrophes, and aliases stay unchanged. An empty list means the user needs to enable notifications in the phone UI. A view’s `notifyDevices` selects its recipient device IDs; use `settings change` to update that list.

For a query or saved view, discover clients with `botlake bin run ui clients list` and consult `botlake bin run ui --help`. `show` changes one client's current view; `settings change` persists shared definitions using the revision from `settings get`. The `schema` command exposes the OpenAPI contract. Filters use the Work UI query syntax, not arbitrary JavaScript or SQL.

Start the lake if it is stopped. If its binary list has no `ui`, report that the UI extension needs selecting in that lake's configuration.
