import { z } from 'zod';
import { deviceIdSchema } from './notifications.ts';

const identifier = z.string().min(1).max(200);
export const clientTargetSchema = z.object({
  source: identifier,
  view: identifier.nullable(),
  query: z.string().max(2000),
  item: z.string().max(500).nullable(),
  group: z.string().max(500).nullable(),
  agent: z.string().max(500).nullable(),
  showGroups: z.boolean(),
});
export const clientStateSchema = clientTargetSchema.extend({
  device: deviceIdSchema.nullable(),
  visible: z.boolean(),
  busy: z.boolean(),
  loading: z.boolean(),
  matchingTasks: z.int().nonnegative(),
});
export const showRequestSchema = z.object({
  client: z.uuid().optional(),
  source: identifier.optional(),
  view: identifier.optional(),
  query: z.string().max(2000).optional(),
  item: z.string().max(500).nullable().optional(),
  group: z.string().max(500).nullable().optional(),
  agent: z.string().max(500).nullable().optional(),
  showGroups: z.boolean().optional(),
});
export const clientCommandSchema = z.object({
  id: z.uuid(),
  expiresAt: z.int().positive(),
  target: clientTargetSchema,
});
export const clientAckSchema = z.object({
  id: z.uuid(),
  status: z.enum(['applied', 'rejected']),
  message: z.string().max(500).nullable(),
  state: clientStateSchema,
});
export const clientInfoSchema = z.object({
  id: z.uuid(),
  name: z.string().min(1).max(80),
  connectedAt: z.string(),
  updatedAt: z.string().nullable(),
  state: clientStateSchema.nullable(),
});
export type ClientTarget = z.infer<typeof clientTargetSchema>;
export type ClientState = z.infer<typeof clientStateSchema>;
export type ClientCommand = z.infer<typeof clientCommandSchema>;
export type ClientAck = z.infer<typeof clientAckSchema>;
export type ShowRequest = z.infer<typeof showRequestSchema>;

export const openRequestSchema = z
  .object({
    id: z.string().min(1).max(500),
    workspace: z.string().min(1).max(4096).optional(),
    source: identifier.optional(),
    device: z.string().min(1).max(80).default('phone'),
  })
  .refine((input) => Boolean(input.workspace) !== Boolean(input.source), {
    message: 'Supply exactly one of workspace or source.',
  });
export const openResultSchema = z.object({
  status: z.enum(['opened', 'notification_sent']),
  device: z.string(),
  source: z.string(),
  id: z.string(),
  kind: z.enum(['task', 'group', 'gate', 'agent']),
  client: z.uuid().nullable(),
});
export function sameTarget(state: ClientTarget, target: ClientTarget): boolean {
  return (
    state.source === target.source &&
    state.view === target.view &&
    state.query === target.query &&
    state.item === target.item &&
    state.agent === target.agent &&
    state.group === target.group &&
    state.showGroups === target.showGroups
  );
}
