import { z } from 'zod';
import { deviceIdSchema } from './notifications.ts';
import { workPrioritySchema } from './work.ts';

export const workFiltersSchema = z.object({
  state: z.enum(['any', 'open', 'closed']),
  readiness: z.enum(['any', 'ready', 'waiting']),
  assignment: z.discriminatedUnion('kind', [
    z.object({ kind: z.enum(['any', 'assigned', 'unassigned', 'person']) }),
    z.object({ kind: z.literal('assignee'), name: z.string() }),
  ]),
  audience: z.enum(['any', 'AFK', 'HITL']),
  origin: z.enum(['any', 'planned', 'unplanned']),
  priorities: z.array(workPrioritySchema.nullable()),
  session: z.enum(['any', 'working', 'quiet', 'queued', 'failed', 'stopped', 'unknown', 'none']),
});
export type WorkFilters = z.infer<typeof workFiltersSchema>;

export const emptyWorkFilters: WorkFilters = {
  state: 'any',
  readiness: 'any',
  assignment: { kind: 'any' },
  audience: 'any',
  origin: 'any',
  priorities: [],
  session: 'any',
};
export const openWorkFilters: WorkFilters = { ...emptyWorkFilters, state: 'open' };

export const workViewIconSchema = z.enum([
  'inbox',
  'list',
  'list-todo',
  'check',
  'circle-check',
  'circle-dot',
  'clock',
  'hourglass',
  'calendar',
  'calendar-days',
  'star',
  'heart',
  'flag',
  'bookmark',
  'tag',
  'tags',
  'folder',
  'folders',
  'layers',
  'layout-grid',
  'target',
  'crosshair',
  'zap',
  'flame',
  'rocket',
  'sparkles',
  'bell',
  'eye',
  'search',
  'filter',
  'user',
  'users',
  'bot',
  'brain',
  'message-circle',
  'messages-square',
  'code',
  'terminal',
  'bug',
  'git-pull-request',
  'shield-check',
  'wrench',
]);
export type WorkViewIcon = z.infer<typeof workViewIconSchema>;

export const savedWorkViewSchema = z.object({
  id: z.string().min(1).max(120),
  name: z.string().trim().min(1).max(80),
  filters: workFiltersSchema,
  pinned: z.boolean().default(false),
  pulse: z.boolean().default(false),
  hidden: z.boolean().default(false),
  icon: workViewIconSchema.nullable().default(null),
  notifyDevices: deviceIdSchema.array().max(32).default([]),
});
export type SavedWorkView = z.infer<typeof savedWorkViewSchema>;

// Starter views are ordinary filter data: users can edit, rename or remove them.
export const starterWorkViews: SavedWorkView[] = z.array(savedWorkViewSchema).parse([
  { id: 'open', name: 'Open', filters: openWorkFilters },
  {
    id: 'mine',
    name: 'My actions',
    filters: {
      ...openWorkFilters,
      readiness: 'ready',
      audience: 'HITL',
      assignment: { kind: 'person' },
    },
  },
  {
    id: 'available',
    name: 'Available',
    filters: {
      ...openWorkFilters,
      readiness: 'ready',
      audience: 'AFK',
      assignment: { kind: 'unassigned' },
    },
  },
  {
    id: 'assigned',
    name: 'Assigned',
    filters: { ...openWorkFilters, assignment: { kind: 'assigned' } },
  },
  { id: 'waiting', name: 'Waiting', filters: { ...openWorkFilters, readiness: 'waiting' } },
  { id: 'closed', name: 'Closed', filters: { ...emptyWorkFilters, state: 'closed' } },
]);

export const lakeViewSchema = z.object({
  id: z.string().min(1),
  name: z.string().trim().min(1, 'Give this combination a name.'),
  sources: z
    .array(z.string().min(1))
    .min(2, 'Select at least two lakes.')
    .refine((sources) => new Set(sources).size === sources.length, 'Select each lake once.'),
});
export type LakeView = z.infer<typeof lakeViewSchema>;
