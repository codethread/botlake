import { z } from 'zod';
import { savedWorkViewSchema, starterWorkViews, lakeViewSchema } from './views.ts';

export const settingsSchema = z.object({
  revision: z.int().nonnegative(),
  views: z.record(z.string(), z.array(savedWorkViewSchema).max(100)),
  lakeViews: z.array(lakeViewSchema).max(32),
});
export type Settings = z.infer<typeof settingsSchema>;
export const freshSettings: Settings = { revision: 0, views: {}, lakeViews: [] };
const source = z.string().min(1).max(120);
const id = z.string().min(1).max(120);
export const settingsActionSchema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('save-view'), source, view: savedWorkViewSchema }),
  z.object({ action: z.literal('delete-view'), source, id }),
  z.object({ action: z.literal('pin-view'), source, id }),
  z.object({
    action: z.literal('move-view'),
    source,
    id,
    direction: z.union([z.literal(-1), z.literal(1)]),
  }),
  z.object({ action: z.literal('save-lake-view'), view: lakeViewSchema }),
  z.object({ action: z.literal('delete-lake-view'), id }),
]);
export const settingsChangeSchema = z.object({
  expectedRevision: z.int().nonnegative(),
  change: settingsActionSchema,
});
export type SettingsAction = z.infer<typeof settingsActionSchema>;
export type SettingsChange = z.infer<typeof settingsChangeSchema>;
export const sourceViews = (settings: Settings, sourceId: string) =>
  settings.views[sourceId] ?? starterWorkViews;
