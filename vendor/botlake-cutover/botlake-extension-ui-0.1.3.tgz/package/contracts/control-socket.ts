import { homedir } from 'node:os';
import { join } from 'node:path';

export const defaultControlSocket = join(homedir(), '.local/state/botlake-ui/control.sock');
