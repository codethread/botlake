import { z } from 'zod';

// Subscriptions authorize an outbound request. Accept browser push services only.
export const pushEndpointSchema = z
  .url()
  .max(4096)
  .refine((value) => {
    const url = new URL(value);
    return (
      url.protocol === 'https:' &&
      url.port === '' &&
      url.username === '' &&
      url.password === '' &&
      url.hash === '' &&
      (url.hostname.endsWith('.push.apple.com') ||
        url.hostname === 'fcm.googleapis.com' ||
        url.hostname === 'updates.push.services.mozilla.com')
    );
  }, 'Use an HTTPS subscription from Apple, Chrome or Firefox.');

export const pushSubscriptionSchema = z.object({
  endpoint: pushEndpointSchema,
  keys: z.object({
    p256dh: z.string().regex(/^[A-Za-z0-9_-]{87}$/),
    auth: z.string().regex(/^[A-Za-z0-9_-]{22}$/),
  }),
});
export type PushSubscriptionData = z.infer<typeof pushSubscriptionSchema>;
export const deviceIdSchema = z.string().regex(/^[a-f0-9]{64}$/);
export const deviceNameSchema = z.string().trim().min(1).max(80);
export const enrollDeviceSchema = z.object({
  subscription: pushSubscriptionSchema,
  kind: z.enum(['phone', 'desktop']),
  name: deviceNameSchema,
});
export type EnrollDevice = z.infer<typeof enrollDeviceSchema>;
export const deviceInfoSchema = z.object({
  id: deviceIdSchema,
  alias: z.string().min(1),
  name: deviceNameSchema,
  revision: z.int().positive(),
  lastSentAt: z.string().nullable(),
  error: z.string().nullable(),
});
export const nameDeviceSchema = z.object({
  id: deviceIdSchema,
  name: deviceNameSchema,
  expectedRevision: z.int().positive(),
});
export const renameNotificationDeviceSchema = nameDeviceSchema.omit({ id: true }).extend({
  endpoint: pushEndpointSchema,
});
export interface PushMessage {
  title: string;
  body: string;
  tag: string;
  url: string;
}
export const notificationStatusSchema = z.object({
  publicKey: z.string(),
  person: z.string(),
  enabled: z.boolean(),
  lastSentAt: z.string().nullable(),
  error: z.string().nullable(),
  watching: z.int().nonnegative(),
  rules: z.int().nonnegative(),
  devices: deviceInfoSchema.array(),
});
export type NotificationStatus = z.infer<typeof notificationStatusSchema>;
