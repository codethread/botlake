import { z } from 'zod';

const attribution = z.object({ by: z.string(), at: z.string() });
const evidence = z.record(z.string(), z.json());
const gateAttempt = z.object({
  at: z.string(),
  outcome: z.enum(['failed', 'errored']),
  message: z.string(),
  evidence: evidence.optional(),
});
export const gateStatusSchema = z.discriminatedUnion('status', [
  z.object({ status: z.literal('pending'), round: z.int().positive() }),
  z.object({
    status: z.literal('waiting'),
    round: z.int().positive(),
    attempts: z.int().positive(),
    last: gateAttempt,
    nextAt: z.string(),
  }),
  z.object({
    status: z.literal('exhausted'),
    round: z.int().positive(),
    attempts: z.int().positive(),
    last: gateAttempt,
  }),
  attribution.extend({
    status: z.literal('cleared'),
    via: z.enum(['probe', 'actor']),
    message: z.string(),
    evidence: evidence.optional(),
  }),
  attribution.extend({ status: z.literal('dismissed'), reason: z.string() }),
]);
export type GateStatus = z.infer<typeof gateStatusSchema>;
export const workPrioritySchema = z.enum(['P0', 'P1', 'P2', 'P3', 'P4']);
const summary = z.object({
  id: z.string(),
  title: z.string(),
  state: z.enum(['open', 'closed']),
  ready: z.boolean(),
  assignee: z.string().nullable(),
  audience: z.enum(['AFK', 'HITL']).nullable(),
  origin: z.enum(['planned', 'unplanned']).nullable(),
  priority: workPrioritySchema.nullable(),
  parent: z.string().nullable(),
});
export const ordinaryWorkSummarySchema = summary.extend({ kind: z.enum(['task', 'group']) });
export const gateSummarySchema = summary.extend({
  kind: z.literal('gate'),
  gate: z.object({ probe: z.string(), status: gateStatusSchema }),
});
export const workSummarySchema = z.discriminatedUnion('kind', [
  ordinaryWorkSummarySchema,
  gateSummarySchema,
]);
/** A read-only observation; its ID belongs to this lake, its source ID to the owner. */
export const workReferenceSchema = summary.extend({
  kind: z.literal('reference'),
  reference: z.object({
    lakeId: z.uuid(),
    workspace: z.string().min(1),
    nodeId: z.string().min(1),
    revision: z.int().positive(),
    observedAt: z.number(),
    status: z.enum(['current', 'stale', 'missing']),
    kind: z.string().nullable(),
  }),
});
const workLinkSchema = z.discriminatedUnion('kind', [
  ordinaryWorkSummarySchema,
  gateSummarySchema,
  workReferenceSchema,
]);
export const workPageSchema = z.object({
  items: z.array(workSummarySchema),
  total: z.int().nonnegative(),
  nextOffset: z.int().nonnegative().nullable(),
});
const assignment = attribution.extend({
  id: z.string(),
  assignee: z.string(),
  release: attribution.extend({ reason: z.string() }).nullable(),
});
const criterionChange = attribution.extend({
  kind: z.enum(['resolved', 'reopened']),
  text: z.string(),
});
const base = {
  id: z.string(),
  title: z.string(),
  description: z.string(),
  state: z.enum(['open', 'closed']),
  revision: z.int().positive(),
  closedBy: z.string().nullable(),
  closedAt: z.string().nullable(),
};
const group = z.object({ ...base, kind: z.literal('group') });
const gate = z.object({
  ...base,
  kind: z.literal('gate'),
  probe: z.string(),
  params: evidence,
  policy: z.object({
    everyMs: z.int().nonnegative(),
    maxAttempts: z.int().positive(),
    timeoutMs: z.int().positive(),
  }),
  status: gateStatusSchema,
});
export const workDetailSchema = z.object({
  item: z.discriminatedUnion('kind', [
    group,
    gate,
    z.object({
      ...base,
      kind: z.literal('task'),
      notes: z.string().nullable(),
      acceptanceCriteria: z.array(
        z.object({
          id: z.string(),
          condition: z.string(),
          state: z.enum(['open', 'resolved']),
          resolution: attribution.extend({ text: z.string() }).nullable(),
        }),
      ),
      assignee: z.string().nullable(),
      assignment: assignment.nullable(),
      audience: z.enum(['AFK', 'HITL']),
      origin: z.enum(['planned', 'unplanned']),
      priority: z.enum(['P0', 'P1', 'P2', 'P3', 'P4']),
    }),
  ]),
  context: z.array(group),
  ready: z.boolean(),
  prerequisites: z.array(workLinkSchema),
  references: z.array(workLinkSchema),
  members: workPageSchema,
  history: z.object({
    assignments: z.array(assignment),
    criteria: z.array(z.object({ id: z.string(), changes: z.array(criterionChange) })),
    closures: z.array(attribution),
    reopenings: z.array(attribution.extend({ reason: z.string() })),
  }),
});

export type WorkSummary = z.infer<typeof workSummarySchema>;
export type WorkGateSummary = z.infer<typeof gateSummarySchema>;
export type WorkGate = z.infer<typeof gate>;
export type WorkReference = z.infer<typeof workReferenceSchema>;
export type WorkLink = z.infer<typeof workLinkSchema>;
export type WorkDetail = z.infer<typeof workDetailSchema>;
export type WorkSnapshot = {
  items: WorkSummary[];
  references: WorkReference[];
  dependencies: WorkDependency[];
  updatedAt: Record<string, string>;
  fetchedAt: string;
};

/** Directed from the prerequisite to the work that depends on it. */
export type WorkDependency = { source: string; target: string };

export const workChangeSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('gate'),
    operation: z.enum(['retry', 'clear', 'dismiss']),
    reason: z.string().trim().min(1),
  }),
  z.object({ action: z.literal('priority'), priority: z.enum(['P0', 'P1', 'P2', 'P3', 'P4']) }),
  z.object({
    action: z.literal('findings'),
    notes: z.string(),
    expectedRevision: z.int().positive(),
  }),
  z.object({
    action: z.literal('resolve'),
    criterion: z.string().min(1),
    text: z.string().trim().min(1),
  }),
  z.object({ action: z.literal('close') }),
  z.object({ action: z.literal('reopen'), reason: z.string().trim().min(1) }),
]);
export type WorkChange = z.infer<typeof workChangeSchema>;
