import { z } from "zod";

export const environmentSchema = z.compile(z.record(z.string(), z.string()));

export const invocationSchema = z.compile(
  z
    .strictObject({
      workspace: z.string(),
      generation: z.string().optional(),
      request_id: z.string().min(1),
      invocation_id: z.string().min(1).optional(),
      name: z.string().min(1),
      identity: z.string().optional(),
      input: z.unknown().optional(),
      argv: z.array(z.string()).optional(),
      payloads: z.record(z.string().min(1), z.string()).optional(),
      cwd: z.string().optional(),
      worktree_root: z.string().optional(),
      git_common_dir: z.string().optional(),
      env: environmentSchema.default({}),
      is_tty: z.boolean().optional(),
      tty_col: z.number().int().positive().nullable().optional(),
      timeout_ms: z.number().positive().optional(),
      output_format: z.enum(["auto", "json"]).optional(),
    })
    .refine((value) => value.argv === undefined || !Object.hasOwn(value, "input"), {
      message: "Choose argv or input, not both",
    }),
);

export const workerMessageSchema = z.compile(
  z.union([invocationSchema, z.strictObject({ cancel: z.string() })]),
);
